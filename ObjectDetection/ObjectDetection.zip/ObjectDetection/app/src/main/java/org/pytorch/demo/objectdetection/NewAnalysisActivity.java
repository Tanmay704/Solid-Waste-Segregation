package org.pytorch.demo.objectdetection;

// pie chart Libraries
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import java.util.ArrayList;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class NewAnalysisActivity extends AppCompatActivity {
    public long plastic_total = 0;
    public long paper_total = 0;
    public long cardboard_total = 0;
    public long metal_total = 0;
    public long thermocol_total = 0;
    public long glass_total = 0;
    public NewAnalysisActivity(){

        getAllCount();
        piechart();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.analysis_activity);
    }

    public void getAllCount() {


        DatabaseReference databaseReference = FirebaseDatabase.getInstance("https://solid-waste-segregation-default-rtdb.firebaseio.com/").getReference("GarbageCount");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot1) {

                plastic_total = 0;
                paper_total = 0;
                cardboard_total = 0;
                metal_total = 0;
                thermocol_total = 0;
                glass_total = 0;
                for(DataSnapshot ds : dataSnapshot1.getChildren()) {
                    for(DataSnapshot ds2 : ds.getChildren()) {

                        Long amount = ds2.child("Plastic").child("Count").getValue(Long.class);
                        plastic_total += amount;
                        amount = ds2.child("Paper").child("Count").getValue(Long.class);
                        paper_total += amount;
                        amount = ds2.child("Cardboard").child("Count").getValue(Long.class);
                        cardboard_total += amount;
                        amount = ds2.child("Metal").child("Count").getValue(Long.class);
                        metal_total += amount;
                        amount = ds2.child("Thermocol").child("Count").getValue(Long.class);
                        thermocol_total += amount;
                        amount = ds2.child("Glass").child("Count").getValue(Long.class);
                        glass_total += amount;

                   }
                }
                System.out.println("())))))))))))))))))))))))))))))))))))))))))))))))))))))))))"+cardboard_total);
                System.out.println("())))))))))))))))))))))))))))))))))))))))))))))))))))))))))"+glass_total);
                System.out.println("())))))))))))))))))))))))))))))))))))))))))))))))))))))))))"+metal_total);
                System.out.println("())))))))))))))))))))))))))))))))))))))))))))))))))))))))))"+paper_total);
                System.out.println("())))))))))))))))))))))))))))))))))))))))))))))))))))))))))"+plastic_total);
                System.out.println("())))))))))))))))))))))))))))))))))))))))))))))))))))))))))"+thermocol_total);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {


            }


        });
    }

    PieChart pieChart;
    PieData pieData;
    PieDataSet pieDataSet;
    ArrayList pieEntries;
    ArrayList PieEntryLabels;

    protected void piechart() {
        getEntries();
        pieDataSet = new PieDataSet(pieEntries, "");
        pieData = new PieData(pieDataSet);
        pieChart.setData(pieData);
        pieDataSet.setColors(ColorTemplate.JOYFUL_COLORS);
        pieDataSet.setSliceSpace(2f);
        pieDataSet.setValueTextColor(Color.WHITE);
        pieDataSet.setValueTextSize(10f);
        pieDataSet.setSliceSpace(5f);
    }
    private void getEntries() {
        pieEntries = new ArrayList<>();
        pieEntries.add(new PieEntry(plastic_total, 0));
        pieEntries.add(new PieEntry(paper_total, 1));
        pieEntries.add(new PieEntry(metal_total, 2));
        pieEntries.add(new PieEntry(glass_total, 3));
        pieEntries.add(new PieEntry(cardboard_total, 4));
        pieEntries.add(new PieEntry(thermocol_total, 5));
    }

}